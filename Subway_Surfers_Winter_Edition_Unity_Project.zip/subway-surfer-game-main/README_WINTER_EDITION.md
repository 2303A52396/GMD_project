# Subway Surfers – Winter Edition (Unity project)

This is a winter-themed modification of the supplied Unity endless-runner project. The original gameplay systems are retained and the visual theme is refreshed.

## Winter changes in this package
- Snowy environment, winter lighting, fog and continuous snowfall are configured by `GameBootstrap.cs`.
- Procedural track scenery includes snow fields, snow-capped mountains, winter buildings, lamps, fir trees, gifts and snowmen.
- Fir trees now have visible snow caps and a colder evergreen palette.
- Standard coin pickups use an icy blue/silver appearance; snowflake and present pickups remain available.
- Menu, HUD, pause and game-over screens use a coordinated frost-blue palette.
- Existing three-lane movement, jumping, sliding, obstacles, collectibles, scoring, pause, restart and game-over systems are retained.

## Open and run
1. Install Unity Hub and Unity Editor **6000.6.7f1** (the version recorded by this project).
2. In Unity Hub choose **Add > Add project from disk** and select this folder.
3. Wait for packages and assets to import.
4. Open `Assets/Scenes/SampleScene.unity`.
5. Press **Play**. The scene's `GameBootstrap` component creates the runtime environment, player, track, snowfall and UI.

## Controls
- Left / Right arrows or A / D: change lane
- Space / W: jump
- Down / S: slide
- Esc: pause
- UI buttons: Play, Settings, Pause, Resume, Restart, Main Menu and Quit

## Important note
The source ZIP did not include a Unity Editor build or a playable standalone executable. This package contains the editable Unity project source. It has been updated at script level, but must be opened and tested in the specified Unity Editor before submission/building.
